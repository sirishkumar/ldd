
// shows how to use memory allocation functions
// Version : 1.0
// Author : Team -C

main(){
	void *p;
	p=100;
	p++;
	printf(" p = %d\n",p);
}
