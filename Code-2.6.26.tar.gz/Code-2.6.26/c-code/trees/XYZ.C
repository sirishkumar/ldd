





main(){
	int *p =0x5687;
	*p=44;
}
