
# define IPC_KEY 9999
# define SHM_UR SHM_R
# define SHM_UW SHM_W
# define SHM_GR SHM_R >>3
# define SHM_GW SHM_W >>3
# define SHM_OR SHM_R >>6
# define SHM_OW SHM_W >>6

