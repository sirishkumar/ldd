/* This program get the message form the mail ID
Author : IDST
Version : 1.0
*/

void pop3recv(int number)
{
	printf("\n The number of Messages received : %d ",number);
	
}
