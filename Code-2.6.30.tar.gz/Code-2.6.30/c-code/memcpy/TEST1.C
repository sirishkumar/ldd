




main(){
	char a[10]="abcdefghi";
	char b[10];
	long i;
//	for(i=0;i<9999999;i++)
	mymemcopy(a,b,10);
	printf("%s\n",b);
}
